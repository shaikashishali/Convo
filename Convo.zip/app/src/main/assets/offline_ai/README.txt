Place your offline AI model files in this folder (e.g., GPT4All, MPT-lite, Alpaca-mini).
Models are large; ensure you follow licensing and store them outside the APK for Play Store size constraints if needed.
