Place your offline TTS model files in this folder. Examples:
- small-tts-model.bin
- voice-config.json

For production, use compressed models and lazy-load them.
