package com.convo
object VoiceManager {
    // Placeholder for offline TTS and voice recognition logic
}