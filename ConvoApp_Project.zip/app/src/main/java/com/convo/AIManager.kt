package com.convo
object AIManager {
    // Placeholder for offline GPT-style model logic
}